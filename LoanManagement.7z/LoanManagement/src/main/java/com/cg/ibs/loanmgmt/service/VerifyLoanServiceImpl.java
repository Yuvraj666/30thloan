package com.cg.ibs.loanmgmt.service;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.loanmgmt.dao.BankerDao;
import com.cg.ibs.loanmgmt.dao.LoanMasterDao;
import com.cg.ibs.loanmgmt.dao.VerificationDetailsDao;
import com.cg.ibs.loanmgmt.entities.Banker;
import com.cg.ibs.loanmgmt.entities.LoanMasterEntity;
import com.cg.ibs.loanmgmt.entities.LoanStatus;
import com.cg.ibs.loanmgmt.entities.VerificationDetailsEntity;
import com.cg.ibs.loanmgmt.model.BankerModel;
import com.cg.ibs.loanmgmt.model.LoanMasterModel;

@Service("verifyLoanService")
public class VerifyLoanServiceImpl implements VerifyLoanService {
	@Autowired
	LoanMasterDao loanMasterDao;
	@Autowired
	ApplyLoanService applyLoanService;
	@Autowired
	BankerDao bankerDao;
	@Autowired
	VerificationDetailsDao verificationDetailsDao;

	@Override
	public List<LoanMasterModel> findLoansToBeVerified(BankerModel bankerModel) {
		Banker banker = bankerDao.findByUserId(bankerModel.getUserId());
		List<LoanMasterEntity> pendingLoans = loanMasterDao.findLoansToBeVerified(banker);
		List<LoanMasterModel> pendingLoansModel = new ArrayList<LoanMasterModel>();
		if (pendingLoans.isEmpty()) {
			pendingLoansModel = null;
			System.out.println("null");
		} else {
			for (LoanMasterEntity loanMasterEntity : pendingLoans) {
				LoanMasterModel loanMasterModel = applyLoanService.valueOf(loanMasterEntity);
				System.out.println(loanMasterModel.getApplicationNumber());
				System.out.println(loanMasterModel.getLoanAccountNumber());
				pendingLoansModel.add(loanMasterModel);
			}
		}
		return pendingLoansModel;
	}

	@Override
	public LoanMasterModel findLoanToBeVerified(BankerModel banker) {
		LoanMasterEntity loanMasterEntity = loanMasterDao.findLoansByAppNum(banker.getVerifyApplicationNumber());
		return applyLoanService.valueOf(loanMasterEntity);
	}

	private BigInteger generateLoanNo(LoanMasterEntity loanMasterEntity) {
		StringBuilder sb = new StringBuilder();
		sb.append(LocalDate.now().getYear()).append(LocalDate.now().getMonthValue())
				.append(loanMasterEntity.getApplicationNumber());
		BigInteger loanNumber = new BigInteger(sb.toString());
		return loanNumber;
	}

	@Transactional
	@Override
	public LoanMasterModel verifyLoan(LoanMasterModel loanMasterModel, Integer choice) {
		LoanMasterEntity loanMasterEntity = loanMasterDao.findLoansByAppNum(loanMasterModel.getApplicationNumber());
		VerificationDetailsEntity detail = new VerificationDetailsEntity();
		switch (choice) {
		case 1:
			loanMasterEntity.setApprovedDate(LocalDate.now());
			loanMasterEntity.setBalance(loanMasterEntity.getLoanAmount());
			loanMasterEntity.setLoanAccountNumber(generateLoanNo(loanMasterEntity));
			loanMasterEntity.setTotalNumOfEmis(loanMasterEntity.getLoanTenure());
			loanMasterEntity.setNextEmiDate(loanMasterEntity.getAppliedDate().plusMonths(1));
			loanMasterEntity.setNumOfEmisPaid(0);
			loanMasterEntity.setStatus(LoanStatus.APPROVED);
			loanMasterEntity.getSavings_Account().setBalance(
			loanMasterEntity.getSavings_Account().getBalance().add(loanMasterEntity.getLoanAmount()));
			
			detail.setApplicationNumber(loanMasterEntity.getApplicationNumber());
			detail.setRemarks(loanMasterModel.getRemarks());
			detail.setQueryStatus(LoanStatus.APPROVED);
			loanMasterDao.save(loanMasterEntity);
			verificationDetailsDao.save(detail);
			break;

		case 2:
			loanMasterEntity.setStatus(LoanStatus.DENIED);
			loanMasterEntity.setLoanDeniedDate(LocalDate.now());
			detail.setApplicationNumber(loanMasterEntity.getApplicationNumber());
			detail.setRemarks(loanMasterModel.getRemarks());
			detail.setQueryStatus(LoanStatus.DENIED);
			loanMasterDao.save(loanMasterEntity);
			verificationDetailsDao.save(detail);
			break;
		}
		loanMasterModel = applyLoanService.valueOf(loanMasterEntity);
		return loanMasterModel;
	}

}
