package com.cg.ibs.loanmgmt.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.loanmgmt.dao.BankerDao;
import com.cg.ibs.loanmgmt.entities.Banker;
import com.cg.ibs.loanmgmt.model.BankerModel;

@Service("bankerService")
public class BankerServiceImpl implements BankerService {
	@Autowired
	BankerDao bankerDao;

	@Override
	public BankerModel findBankerByUserId(String userId) {
		
		Banker bankerEntity = bankerDao.findByUserId(userId);
		System.out.println("hello");
		BankerModel banker = valueOf(bankerEntity);
		return banker;
		}

	@Override
	public BankerModel valueOf(Banker banker) {
		BankerModel bankerModel = new BankerModel();
		bankerModel.setBankerId(banker.getBankerId());
		bankerModel.setUserId(banker.getUserId());
		bankerModel.setPassword(banker.getPassword());
		return bankerModel;
	}

	@Override
	public Banker valueOf(BankerModel banker) {
		Banker bankerEntity =new Banker();
		bankerEntity.setBankerId(banker.getBankerId());
		bankerEntity.setUserId(banker.getUserId());
		bankerEntity.setPassword(banker.getPassword());
		return bankerEntity;
	}
	
}
