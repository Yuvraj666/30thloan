package com.cg.ibs.loanmgmt.entities;

public enum LoanStatus {
	SENT_FOR_VERIFICATION,APPROVED, DENIED, PRE_CLOSURE_VERIFICATION, PRE_CLOSED, PRE_CLOSURE_DENIED, CLOSED;
}
