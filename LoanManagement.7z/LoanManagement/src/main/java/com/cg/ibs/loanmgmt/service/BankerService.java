package com.cg.ibs.loanmgmt.service;

import com.cg.ibs.loanmgmt.entities.Banker;
import com.cg.ibs.loanmgmt.model.BankerModel;

public interface BankerService {
	BankerModel findBankerByUserId(String userId);
	BankerModel valueOf(Banker banker);
	Banker valueOf(BankerModel banker);
}
