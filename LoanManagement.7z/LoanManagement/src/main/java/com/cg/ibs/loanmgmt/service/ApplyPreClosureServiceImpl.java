package com.cg.ibs.loanmgmt.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.loanmgmt.dao.AccountDao;
import com.cg.ibs.loanmgmt.dao.AccountHoldingDao;
import com.cg.ibs.loanmgmt.dao.BankerDao;
import com.cg.ibs.loanmgmt.dao.CustomerDao;
import com.cg.ibs.loanmgmt.dao.LoanMasterDao;
import com.cg.ibs.loanmgmt.entities.Account;
import com.cg.ibs.loanmgmt.entities.AccountHolding;
import com.cg.ibs.loanmgmt.entities.Banker;
import com.cg.ibs.loanmgmt.entities.LoanMasterEntity;
import com.cg.ibs.loanmgmt.entities.LoanStatus;
import com.cg.ibs.loanmgmt.ibsexception.IBSException;
import com.cg.ibs.loanmgmt.model.AccountModel;
import com.cg.ibs.loanmgmt.model.LoanMasterModel;

@Service("applyPreClosureService")
public class ApplyPreClosureServiceImpl implements ApplyPreClosureService {

	@Autowired
	CustomerDao customerDao;
	@Autowired
	LoanMasterDao loanMasterDao;
	@Autowired
	ApplyLoanService applyLoanService;
	@Autowired
	AccountDao accountDao;
	@Autowired
	AccountHoldingDao accountHoldingDao;
	@Autowired
	BankerDao bankerDao;

	@Override
	public List<LoanMasterModel> getPreClosureLoansByUserId(String userId) throws IBSException {
		List<LoanMasterEntity> preClosureLoan = loanMasterDao
				.findForPreClosureByCustomer(customerDao.findByUserId(userId));
		List<LoanMasterModel> preClosureLoans = new ArrayList<LoanMasterModel>();
		for (LoanMasterEntity loanMasterEntity : preClosureLoan) {
			//if (loanMasterEntity.getNumOfEmisPaid() >= 0.25 * loanMasterEntity.getTotalNumOfEmis()) {
				LoanMasterModel loanMasterModel = applyLoanService.valueOf(loanMasterEntity);
				preClosureLoans.add(loanMasterModel);
			//}
		}
		return preClosureLoans;
	}
	

	@Override
	public List<AccountModel> findSavingsAccountsByCustomer(LoanMasterModel loanMasterModel) {
		List<AccountHolding> userSavingAccount = accountHoldingDao.findByCustomer(customerDao.findByUserId(loanMasterModel.getCustomerUserId()));
		List<AccountModel> userSavingsAccount = new ArrayList<AccountModel>();
		LoanMasterEntity loanMasterEntity = loanMasterDao.findByLoanAccountNumber(loanMasterModel.getLoanAccountNumber());
		for (AccountHolding accountHolding : userSavingAccount) {
			Account acc = accountDao.findById(accountHolding.getAccount().getAccNo()).get();
			if(acc.getBalance().compareTo(loanMasterEntity.getBalance())==1){
				AccountModel accTemp = valueOf(acc);
				userSavingsAccount.add(accTemp);	
			}
			
		}
		return userSavingsAccount;
	}
	
	private AccountModel valueOf(Account account) {
		AccountModel accountModel = new AccountModel();
		accountModel.setAccNo(account.getAccNo());
		accountModel.setBalance(account.getBalance());
		accountModel.setAccCreationDate(account.getAccCreationDate());
		accountModel.setAccStatus(account.getAccStatus());
		accountModel.setAccType(account.getAccType());

		return accountModel;
	}


	@Override
	@Transactional
	public LoanMasterModel applyPreClosure(LoanMasterModel loanMasterModel) {
		LoanMasterEntity loanMasterEntity = loanMasterDao.findByLoanAccountNumber(loanMasterModel.getLoanAccountNumber());
		loanMasterEntity.setPreclosureAppliedDate(LocalDate.now());
		loanMasterEntity.setStatus(LoanStatus.PRE_CLOSURE_VERIFICATION);
		loanMasterEntity.setPre_Closure_Approver(appointBankAdmins());
		loanMasterEntity.setSavings_Account(accountDao.findById(loanMasterModel.getSavingsAccount()).get());
		loanMasterDao.save(loanMasterEntity);
		loanMasterModel = applyLoanService.valueOf(loanMasterEntity);
		return loanMasterModel;
	}
	private Banker appointBankAdmins() {
		List<Banker> registeredBankers = bankerDao.findAll();
		for (Banker banker : registeredBankers) {
			System.out.println(registeredBankers);	
		}
		Banker verifyLoanBanker;
		int lastBankAdminIndex = -1;
		BigInteger maxApplicationNumber = loanMasterDao.findMaxApplicationNumber();
		System.out.println(maxApplicationNumber);
		LoanMasterEntity latestLoan = loanMasterDao.findLoansByAppNum(maxApplicationNumber);
		if(latestLoan!=null) {
		lastBankAdminIndex = registeredBankers.indexOf(latestLoan.getPre_Closure_Approver());
		}
		if (lastBankAdminIndex == (registeredBankers.size() - 1) || lastBankAdminIndex == -1) {
			verifyLoanBanker = registeredBankers.get(0);
		}else {
			verifyLoanBanker = registeredBankers.get(lastBankAdminIndex + 1);
		}
		return verifyLoanBanker;
	}


}
