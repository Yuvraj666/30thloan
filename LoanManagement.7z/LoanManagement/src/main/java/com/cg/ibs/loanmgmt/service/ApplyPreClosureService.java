package com.cg.ibs.loanmgmt.service;

import java.util.List;

import com.cg.ibs.loanmgmt.ibsexception.IBSException;
import com.cg.ibs.loanmgmt.model.AccountModel;
import com.cg.ibs.loanmgmt.model.LoanMasterModel;

public interface ApplyPreClosureService {
	List<LoanMasterModel> getPreClosureLoansByUserId(String userId) throws IBSException;

	List<AccountModel> findSavingsAccountsByCustomer(LoanMasterModel loanMasterModel);
	
	LoanMasterModel applyPreClosure(LoanMasterModel loanMasterModel);
}
