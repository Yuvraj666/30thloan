package com.cg.ibs.loanmgmt.entities;

public enum PaymentMode {
	AUTO,MANUAL
}
