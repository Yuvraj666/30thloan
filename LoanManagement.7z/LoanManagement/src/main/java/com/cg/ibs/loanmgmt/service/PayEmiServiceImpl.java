package com.cg.ibs.loanmgmt.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.loanmgmt.dao.AccountDao;
import com.cg.ibs.loanmgmt.dao.AccountHoldingDao;
import com.cg.ibs.loanmgmt.dao.CustomerDao;
import com.cg.ibs.loanmgmt.dao.EmiTransactionDao;
import com.cg.ibs.loanmgmt.dao.LoanMasterDao;
import com.cg.ibs.loanmgmt.dao.TransactionDao;
import com.cg.ibs.loanmgmt.entities.Account;
import com.cg.ibs.loanmgmt.entities.AccountHolding;
import com.cg.ibs.loanmgmt.entities.EmiTransaction;
import com.cg.ibs.loanmgmt.entities.LoanMasterEntity;
import com.cg.ibs.loanmgmt.entities.LoanStatus;
import com.cg.ibs.loanmgmt.entities.Transaction;
import com.cg.ibs.loanmgmt.entities.TransactionMode;
import com.cg.ibs.loanmgmt.entities.TransactionType;
import com.cg.ibs.loanmgmt.ibsexception.ExceptionMessages;
import com.cg.ibs.loanmgmt.ibsexception.IBSException;
import com.cg.ibs.loanmgmt.model.AccountModel;
import com.cg.ibs.loanmgmt.model.LoanMasterModel;

@Service
public class PayEmiServiceImpl implements PayEmiService {
	@Autowired
	private LoanMasterDao loanMasterDao;
	@Autowired
	private CustomerDao customerDao;
	@Autowired
	private ApplyLoanService applyLoanService;
	@Autowired
	private AccountHoldingDao accountHoldingDao;
	@Autowired
	private AccountDao accountDao;
	@Autowired
	private TransactionDao transactionDao;
	@Autowired
	private EmiTransactionDao emiTransactionDao;

	@Override
	public List<LoanMasterModel> getApprovedLoanListByUserId(String userId) throws IBSException {
		List<LoanMasterEntity> activeEnLoans = loanMasterDao.findForEmiByCustomer(customerDao.findByUserId(userId));
		List<LoanMasterModel> activeLoans = new ArrayList<LoanMasterModel>();
		if (activeEnLoans.isEmpty()) {
			activeLoans = null;
		} else {
			for (LoanMasterEntity loanMasterEntity : activeEnLoans) {
				LoanMasterModel loanModel = applyLoanService.valueOf(loanMasterEntity);
				activeLoans.add(loanModel);
			}
		}
		return activeLoans;
	}

	@Override
	public LoanMasterModel getLoanByLoanNum(BigInteger loanAccountNumber) throws IBSException {
		LoanMasterEntity loanMasterEntity = loanMasterDao.findByLoanAccountNumber(loanAccountNumber);
		LoanMasterModel loanMasterModel = applyLoanService.valueOf(loanMasterEntity);
		return loanMasterModel;
	}

	@Override
	public List<AccountModel> findSavingsAccountsByCustomer(String userId, LoanMasterModel loanMasterModel)
			throws IBSException {
		List<AccountHolding> userSavAccounts = accountHoldingDao.findByCustomer(customerDao.findByUserId(userId));
		List<AccountModel> savingAccounts = new ArrayList<AccountModel>();
		for (AccountHolding acc : userSavAccounts) {
			Account tempAcc = new Account();
			AccountModel accountModel = new AccountModel();
			tempAcc = accountDao.findById(acc.getAccount().getAccNo()).get();
			if (tempAcc.getBalance().compareTo(loanMasterModel.getEmiAmount()) == 1) {
				accountModel = valueOf(tempAcc);
				savingAccounts.add(accountModel);
			}
		}
		if (savingAccounts.isEmpty()) {
			throw new IBSException(ExceptionMessages.MESSAGEFORINSUFFICIENTBALANCE);
		}
		return savingAccounts;
	}

	private AccountModel valueOf(Account account) {
		AccountModel accountModel = new AccountModel();
		accountModel.setAccNo(account.getAccNo());
		accountModel.setBalance(account.getBalance());
		accountModel.setAccCreationDate(account.getAccCreationDate());
		accountModel.setAccStatus(account.getAccStatus());
		accountModel.setAccType(account.getAccType());

		return accountModel;
	}

	@Transactional
	@Override
	public LoanMasterModel updateLoanPostEmi(BigInteger loanAccountNumber, BigInteger savingsAccountNumber)
			throws IBSException {
		LoanMasterEntity loanMasterEntity = loanMasterDao.findByLoanAccountNumber(loanAccountNumber);
		Account savingsAccount = accountDao.findById(savingsAccountNumber).get();
		loanMasterEntity.setBalance(loanMasterEntity.getBalance().subtract(calculatePaidPrinciple(loanMasterEntity)));
		loanMasterEntity.setNumOfEmisPaid(loanMasterEntity.getNumOfEmisPaid() + 1);
		loanMasterEntity.setNextEmiDate(loanMasterEntity.getNextEmiDate().plusMonths(1));
		savingsAccount.setBalance(savingsAccount.getBalance().subtract(loanMasterEntity.getEmiAmount()));
		debitTransaction(loanMasterEntity, savingsAccount); // Debit Transaction
		creditTransaction(loanMasterEntity, savingsAccount); // Credit Transaction
		if(loanMasterEntity.getNumOfEmisPaid().equals(loanMasterEntity.getTotalNumOfEmis())) {
			loanMasterEntity.setStatus(LoanStatus.CLOSED);
		}
		loanMasterEntity = loanMasterDao.save(loanMasterEntity);
		savingsAccount = accountDao.save(savingsAccount);
		System.out.println(loanMasterEntity.getBalance());
		LoanMasterModel loanMasterModel = applyLoanService.valueOf(loanMasterEntity);
		return loanMasterModel;
	}

	private Transaction debitTransaction(LoanMasterEntity loanMasterEntity, Account savingsAccount)
			throws IBSException {
		Transaction transaction = new Transaction();
		transaction.setAccount(savingsAccount);
		transaction.setCurrentBalance(savingsAccount.getBalance());
		transaction.setReferenceId(loanMasterEntity.getLoanAccountNumber().toString());
		transaction.setTransactionAmount(loanMasterEntity.getEmiAmount());
		transaction.setTransactionDate(LocalDateTime.now());
		transaction.setTransactionDescription("Payment for Loan Number : " + loanMasterEntity.getLoanAccountNumber());
		transaction.setTransactionMode(TransactionMode.ONLINE);
		transaction.setTransactionType(TransactionType.DEBIT);
		try {
			transactionDao.save(transaction);
		} catch (Exception e) {
			throw new IBSException(ExceptionMessages.MESSAGEFORNOTRANSACTION);
		}
		transactionDao.save(transaction);
		return transaction;
	}

	private EmiTransaction creditTransaction(LoanMasterEntity loanMasterEntity, Account savingsAccount)
			throws IBSException {
		EmiTransaction transaction = new EmiTransaction();
		transaction.setEmiNumber(loanMasterEntity.getNumOfEmisPaid());
		transaction.setLoanMasterAccountNumber(loanMasterEntity);
		transaction.setTransactionAmount(loanMasterEntity.getEmiAmount());
		transaction.setTransactionDate(LocalDateTime.now());
		transaction.setTransactionDescription("Payment for Loan Number:" + loanMasterEntity.getLoanAccountNumber());
		transaction.setTransactionMode(TransactionMode.ONLINE);
		transaction.setTransactionType(TransactionType.CREDIT);
		transaction.setReferenceId(savingsAccount.getAccNo().toString());
		try {
			emiTransactionDao.save(transaction);
		} catch (Exception e) {
			throw new IBSException(ExceptionMessages.MESSAGEFORNOTRANSACTION);
		}
		return transaction;
	}

	private BigDecimal calculatePaidInterest(LoanMasterEntity loanMasterEntity) {
		BigDecimal balance = loanMasterEntity.getBalance();
		Float rate = loanMasterEntity.getLoanInterest() / 100;
		BigDecimal paidInterest = (balance.multiply(BigDecimal.valueOf(Math.pow(1 + rate, 1.0 / 12.0)))
				.subtract(balance));
		return paidInterest;
	}

	private BigDecimal calculatePaidPrinciple(LoanMasterEntity loanMasterEntity) {
		BigDecimal paidPrinciple = loanMasterEntity.getEmiAmount().subtract(calculatePaidInterest(loanMasterEntity));
		return paidPrinciple;
	}



}
